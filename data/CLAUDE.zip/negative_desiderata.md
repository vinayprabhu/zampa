# negative_desiderata.md
### What to keep OUT of an AMP, and the traps that produce a great MIC and a dead drug

**Framing.** A low predicted MIC is necessary and nowhere near sufficient. Most AMP programs die on toxicity, stability, salt/serum, or manufacturability, not on potency. Each item below is a reason a high-scoring sequence should be down-weighted or rejected [1][4].

---

## 1. The central trap: buying MIC with hydrophobicity

Increasing hydrophobicity (more Leu/Ile/Phe/Trp, higher mean hydrophobicity, wider hydrophobic arc, higher hydrophobic moment) reliably lowers MIC and just as reliably raises **hemolysis and mammalian cytotoxicity**. Hemolytic activity is directly correlated with hydrophobicity across peptide series [2][5]. The therapeutic index, not the MIC, is the objective; rational redesigns have improved TI by ~10^2 to 10^3 by *reducing* hydrophobicity and inserting a specificity determinant while holding activity constant [3].

**Reject / penalize:**
- Hydrophobic fraction above ~0.55 to 0.60.
- Three or more aromatic residues, or more than two tryptophans, in a short peptide.
- Contiguous hydrophobic runs longer than ~4 residues.
- Very high hydrophobic moment combined with a wide (>200 deg) nonpolar arc (deep transmembrane, barrel-stave, toxic).

## 2. The second trap: charge maximization

More positive charge helps capture but past ~+7 to +9 it (i) invites the exact resistance defenses that neutralize charge (L-Ara4N, pEtN, mcr, MprF) and (ii) drives **polycation nephrotoxicity** analogous to the dose-limiting toxicity of polymyxins. Hypercationic sequences also bind serum proteins and heparin nonspecifically.

**Reject / penalize:** net charge > +9; runs of 4+ consecutive K/R.

## 3. ADMET and physiological-condition failure modes

| Failure mode | Cause | Consequence | Design guard |
|---|---|---|---|
| Hemolysis / cytotoxicity | Excess hydrophobicity, wide hydrophobic arc, deep insertion | Narrow therapeutic index | Keep hydrophobicity mid-band; moderate arc; interfacial depth |
| Salt / divalent-cation sensitivity | Physiological Na+, Mg2+, Ca2+ screen electrostatics | Activity lost at 150 mM NaCl / 1 to 2 mM Mg2+ | Test in physiological salt; do not rely purely on charge; add structure (disulfides) |
| Protease degradation | Trypsin cleaves after K/R; chymotrypsin after aromatics; serum proteases | Short half-life; the very residues that give activity are the cleavage sites | Cyclization, disulfides, D-residues, or PrAMP scaffolds for stability |
| Serum-protein sequestration | Albumin / lipoprotein binding | Low free active fraction in vivo | Watch high hydrophobicity and high Boman-type binding potential |
| Aggregation in vitro | Long beta-prone hydrophobic stretches | Poor solubility, inflammation, activity loss, oracle false-negatives | Avoid long I/V/F/Y/W/L/T runs; keep beta-aggregation low |
| Immunogenicity / mast-cell degranulation | Some cationic amphipathic peptides trigger histamine release | Local toxicity, inflammation | Screen amphipathicity extremes |
| Endotoxin handling | Strong LPS binding can be neutralizing or can liberate endotoxin | Variable in vivo effect | Evaluate LPS effects explicitly, do not assume benefit |
| Off-target promiscuity | Very high protein-binding potential (Boman-type) | Nonspecific interactions, toxicity | Flag high-Boman outliers |

Clinical translation of AMPs is repeatedly reported as blocked by toxicity, instability, and manufacturing constraints, which is why these guards matter as much as potency [1][4].

## 4. Synthesizability gotchas (solid-phase peptide synthesis, AAPPTec-style)

A sequence that cannot be made cleanly, cheaply, and reproducibly is not a candidate.

- **Odd or excess cysteines:** an unpaired thiol invites oxidation and disulfide scrambling; three or more Cys create regioselective-folding headaches. Prefer zero or a defined even number of Cys with a clear pairing scheme.
- **Long hydrophobic / beta-branched runs:** Ile/Val/Thr and long Leu/Phe stretches aggregate on-resin, causing deletion sequences and low yield.
- **Methionine:** oxidation liability; avoid or plan for it.
- **Asn/Gln:** deamidation; N-terminal Gln forms pyroglutamate.
- **Asp-Pro and Asp-Gly:** aspartimide formation and acid-labile cleavage; avoid where possible.
- **Arg-rich stretches:** slow, incomplete couplings; increase cost.
- **His and Cys:** racemization risk under standard activation.
- **Length and solubility:** cost scales with length; very hydrophobic long peptides are hard to purify and may be insoluble after cleavage. Favor 12 to 30 residues.

## 5. Modeling-artifact gotchas (specific to this benchmark)

The organizers' own benchmark, BATTLE-AMP, found that **most predictors cannot distinguish active peptides from inactive sequences of identical amino-acid composition**, and that **activity cliffs (single-substitution activity flips) are unresolved by both ML and molecular dynamics** [6]. Consequences for selection:

- Treat any oracle score (including the DPS used here and a future APEX score) as **noisy and locally unstable**; do not over-fit the top list to razor-thin score differences.
- A candidate one substitution away from a known active is a red flag for a cliff, not a safe bet.
- Prefer candidates whose predicted activity is robust to composition-preserving shuffles and small edits (an explicit robustness check to run once the oracle is available).
- Diversify structural class so a systematic proxy blind-spot does not sink the whole set.

## 6. Hard exclusion checklist (fast filters)

Reject a sequence if any of the following hold:
1. Length outside 8 to 50, or contains non-standard residues.
2. Net charge <= 0 or > +9.
3. Hydrophobic fraction > 0.60, or hydrophobic run > 5.
4. Aromatic fraction > 0.25, or Trp count > 2 in <20-residue peptides.
5. Odd cysteine count, or Cys count > 2 without a pairing plan.
6. Homorepeat run >= 4 of any residue.
7. High beta-aggregation propensity (long beta-prone hydrophobic stretch).
8. Near-duplicate of a known AMP under the authoritative novelty gate (MMseqs2 / normalized global alignment vs MarLys, DBAASP, DRAMP, APD3).

---

### References
1. AI-Driven Discovery and Optimization of AMPs Targeting ESKAPE Pathogens (toxicity/instability/manufacturing barriers), MDPI Microorganisms 2026. https://www.mdpi.com/2076-2607/14/3/591
2. Structure-activity relationship, phylloseptins (hemolysis rises with hydrophobicity), Dovepress DDDT 2019. https://www.dovepress.com/structurendashactivity-relationship-of-an-antimicrobial-peptide-phyllo-peer-reviewed-fulltext-article-DDDT
3. Rational alpha-helical AMP design, therapeutic-index gains by lowering hydrophobicity + specificity determinant, PubMed 21219588. https://pubmed.ncbi.nlm.nih.gov/21219588/
4. Design methods for AMPs with improved performance (stability/toxicity/optimization), PMC10802102. https://pmc.ncbi.nlm.nih.gov/articles/PMC10802102/
5. Amphipathicity/hydrophobicity and the hemolysis trade-off; aggregation propensity as a top toxicity discriminator. https://www.researchgate.net/publication/293017656
6. BATTLE-AMP: Benchmarking Antimicrobial Peptide Predictors (actives vs same-composition inactives; unresolved activity cliffs), bioRxiv 2026. https://www.biorxiv.org/content/10.64898/2026.06.19.733349v1
