# positive_desiderata.md
### What a designer should engineer INTO an AMP targeting the 20-strain panel

**Framing.** These are the "aim-for" properties. Every numeric window is a productive region, not a hard threshold, and several are scale-dependent (hydrophobic moment and hydrophobicity differ by hydrophobicity scale). Values below use the Eisenberg consensus scale unless noted. The dominant lesson from the literature is **balance, not maximization**: activity and selectivity peak in interior windows and degrade past them [1][2][5].

---

## 1. Primary property windows (helical cationic amphipathic reference class)

| Property | Productive window | Direction / note | Basis |
|---|---|---|---|
| Length | 12 to 30 residues (8 to 50 allowed) | Shorter reduces synthesis cost and hemolysis while retaining activity | [3][6] |
| Net charge (z, pH 7) | +3 to +8, optimum ~+4 to +6 | Positive but not maximal; excess is neutralized by L-Ara4N/pEtN/MprF | [4][6] |
| Isoelectric point (pI) | 9.5 to 12 | Cationic character | [6] |
| Normalized mean hydrophobicity (H) | balanced, not maximal | Above the optimum, hemolysis rises faster than activity | [1][4][5] |
| Hydrophobic fraction | 0.35 to 0.55 | ~40 to 55% hydrophobic residues | [1][3] |
| Hydrophobic moment (uH) | substantial, mid-range | High amphipathicity, capped to avoid deep insertion | [4][6] |
| Helix propensity (membrane) | high | Fold on membrane contact, disordered in water | [2][5] |
| Aqueous secondary structure | mostly disordered | Coil in solution, coil-to-helix on the bilayer | [5] |

## 2. The mandate-named descriptors, defined and targeted

**Hydrophobic moment (uH).** Eisenberg vector sum of residue hydrophobicities at the helical angle (100 deg/residue), normalized by length. Measures amphipathicity. Aim mid-to-high; extreme uH tracks with hemolysis, so pair it with a modest hydrophobic arc. Reported productive bands are scale-dependent (for example uH in [0.5, 0.75] on one normalized scale, 0.2 to 1.0 on another) [4][6].

**Normalized hydrophobicity.** Mean per-residue hydrophobicity rescaled to [0,1]. Keep it in a middle band. The hemolysis-vs-activity trade-off is monotonic in hydrophobicity past the optimum, so more is not better [1][5].

**Net charge.** Sum of protonation-state charges at pH 7 (Henderson-Hasselbalch). Drives initial electrostatic capture on anionic LPS/PG. Optimum ~+4 to +6; going higher invites charge-evasion defenses and polycation nephrotoxicity [4][6].

**Isoelectric point.** pH of zero net charge. High pI (9.5 to 12) confirms cationic identity and net positive charge across physiological pH.

**Penetration depth.** How deep the peptide sits in the bilayer (surface/S-state versus inserted/I-state, from oriented CD and solid-state NMR). Interfacial-to-moderate penetration favors selective carpet/toroidal action; deep transmembrane insertion favors barrel-stave pores and correlates with mammalian toxicity. **Target interfacial-to-moderate depth** for a good therapeutic index.

**Tilt angle.** Angle of the helix axis to the bilayer normal. Near-parallel-to-surface (large tilt, in-plane) orientation supports carpet/toroidal, often more selective mechanisms; near-perpendicular (transmembrane, small tilt) supports pores and higher toxicity. **Target a surface-associated/tilted orientation.**

**Disordered conformation propensity.** Tendency to be unstructured in aqueous buffer and fold only upon membrane binding. High aqueous disorder plus membrane-induced folding lowers circulation-phase aggregation and off-target toxicity. This was identified as one of the most critical descriptors separating antimicrobial-and-non-hemolytic peptides from toxic ones [5]. **Target high aqueous disorder.**

**Linear moment.** First-order (asymmetry) moment of hydrophobicity along the sequence, that is an N-to-C hydrophobicity gradient. A modest linear moment can aid oriented insertion and terminal anchoring. **Target modest, not extreme** (a strong end-loaded hydrophobic block promotes aggregation).

**Propensity to aggregation in vitro.** Tendency to self-associate/form amyloid-like assemblies. Usually harmful (poor solubility, bioavailability, inflammation), occasionally exploited for controlled nanostructures. **Target low intrinsic aggregation** (avoid long contiguous beta-prone hydrophobic stretches); flagged as a top discriminating property for the safe cluster [5].

**Angle subtended by hydrophobic residues (hydrophobic arc / polar angle).** The arc of the helical wheel occupied by nonpolar residues. A narrower nonpolar face (roughly 120 to 180 deg) tends to be more selective and less hemolytic; a very wide hydrophobic arc increases indiscriminate membrane disruption. **Target a moderate hydrophobic arc (~120 to 180 deg).** This is the "specificity determinant" lever used to raise therapeutic index in rational Gram-negative designs [3].

**Amphiphilicity index.** Aggregate measure of amphipathic character (closely related to uH). **Target high but balanced** so the nonpolar face is defined without being dominant.

**Propensity to PPII (polyproline II) coil.** Fraction favoring the left-handed PPII helix. Central to proline-rich AMPs (PrAMPs), whose functional conformation for ribosome/DnaK inhibition is PPII. **Target high for the proline-rich class; low/irrelevant for the helical lytic class.**

## 3. Sequence-composition heuristics that generalize across the panel

- **Cationic residues:** lysine and arginine both work; arginine gives stronger, geometry-tolerant electrostatics and better guanidinium-phosphate contacts, useful against capsule and LPS. Mixed K/R often optimizes selectivity.
- **Aromatic anchors:** one to two tryptophans (interfacial anchoring at the membrane headgroup region) boost activity; keep tryptophan count low to control hemolysis. Trp/Arg-rich short peptides can be potent and low-hemolytic (for example ZY13-type) [3].
- **Specificity determinants:** placing a single charged residue in the center of the nonpolar face reduces hemolysis dramatically while preserving antibacterial activity, the core trick behind therapeutic-index gains up to ~10^3 in Gram-negative-focused designs [3].
- **Helix stabilizers:** alanine, leucine, and correctly spaced i,i+3 / i,i+4 hydrophobic contacts sharpen amphipathic helices.
- **Terminal choices (post-design):** C-terminal amidation raises net charge and helicity and is standard; consider it in the synthesized construct rather than the sequence string.

## 4. Structural-class palette (the library must span these)

1. **Helical cationic amphipathic** (magainin/cecropin/LL-37 architecture): the generalist workhorse.
2. **Disulfide beta-hairpin / beta-sheet** (protegrin/tachyplesin architecture): rigid, protease-resistant, potent against Gram-negatives; one to two Cys pairs.
3. **Proline-rich (PrAMP)** (apidaecin/oncocin architecture): non-lytic, intracellular target (ribosome/DnaK), intrinsically low hemolysis; PPII conformation; strong on Enterobacteriaceae.
4. **Cyclic / conformationally constrained mimics** (gramicidin-S-like alternating cationic/hydrophobic; head-to-tail or disulfide cyclization): rigidity raises stability and can raise selectivity.
5. **Trp/Arg-rich short peptides** (indolicidin/lactoferricin architecture): compact, cheap, membrane-anchoring.
6. **Cationic disordered/coil** peptides: high charge, low structure, fold on contact.

## 5. One-line design summary

Aim for a compact (12 to 30 aa), moderately cationic (~+4 to +6), amphipathic peptide that is disordered in water and folds on the anionic membrane, with a moderate hydrophobic arc and interfacial insertion depth, and hedge mechanism across the six structural classes rather than maximizing any single scalar.

---

### References
1. Accelerating AMP Discovery with Latent Structure, arXiv:2212.09450 (charge, hydrophobicity, hydrophobic-moment acceptance windows; coil-length filter). https://arxiv.org/pdf/2212.09450
2. AI-Driven Discovery and Optimization of AMPs Targeting ESKAPE Pathogens, MDPI Microorganisms 2026. https://www.mdpi.com/2076-2607/14/3/591
3. Rational design of alpha-helical AMPs for Gram-negative pathogens (charge, specificity determinants, hydrophobe location; therapeutic-index gains), PubMed 21219588. https://pubmed.ncbi.nlm.nih.gov/21219588/ ; supporting review PMC10802102. https://pmc.ncbi.nlm.nih.gov/articles/PMC10802102/
4. HMAMP: Hypervolume-Driven Multi-Objective AMP Design (charge 2-7, uH 0.2-1.0, pI 8.9-12, length windows), arXiv:2405.00753. https://arxiv.org/pdf/2405.00753
5. Amphipathicity/hydrophobicity balance and hemolysis; disordered conformation and aggregation propensity as top discriminators for antimicrobial-non-hemolytic peptides (mean uH ~1.2, net charge ~4.5, pI ~10.9). https://www.researchgate.net/publication/293017656
6. Machine Learning-Assisted Prediction and Generation of AMPs, Small Science 2025 (property distributions, ESKAPE activity). https://onlinelibrary.wiley.com/doi/10.1002/smsc.202400579
