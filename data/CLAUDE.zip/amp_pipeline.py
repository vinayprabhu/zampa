#!/usr/bin/env python3
"""
AMP Challenge pipeline: zero-shot generation of 50k novel AMPs + top-100 selection.

HONEST SCOPE (read this):
- This produces a biophysically-principled peptide LIBRARY and a transparent
  ranking by a computable Design Priority Score (DPS).
- DPS is NOT an APEX-oracle MIC. No oracle weights are available in this
  environment and the network is disabled, so no MIC is predicted here. DPS is a
  proxy built from the positive/negative desiderata. APEX 1.1 scoring + MMseqs2
  novelty gating vs MarLys/MLAMP_db are the authoritative downstream steps to run
  once the oracle and MLAMP_db.json are in hand.
- Novelty here = exact-dedup + a coarse k-mer identity gate vs ~30 canonical AMPs.
  This is a placeholder for the authoritative MMseqs2/Needleman-Wunsch gate.
"""

import math, random, json
from collections import Counter
import numpy as np
import pandas as pd

random.seed(1729)          # taxicab number; deterministic run
np.random.seed(1729)

AA = "ACDEFGHIKLMNPQRSTVWY"

# --- Amino acid scales -------------------------------------------------------
# Eisenberg consensus hydrophobicity (used for hydrophobic moment)
EISENBERG = {'A':0.62,'R':-2.53,'N':-0.78,'D':-0.90,'C':0.29,'Q':-0.85,'E':-0.74,
             'G':0.48,'H':-0.40,'I':1.38,'L':1.06,'K':-1.50,'M':0.64,'F':1.19,
             'P':0.12,'S':-0.18,'T':-0.05,'W':0.81,'Y':0.26,'V':1.08}
# Kyte-Doolittle (GRAVY)
KD = {'A':1.8,'R':-4.5,'N':-3.5,'D':-3.5,'C':2.5,'Q':-3.5,'E':-3.5,'G':-0.4,
      'H':-3.2,'I':4.5,'L':3.8,'K':-3.9,'M':1.9,'F':2.8,'P':-1.6,'S':-0.8,
      'T':-0.7,'W':-0.9,'V':4.2,'Y':-1.3}
# Chou-Fasman alpha-helix propensity
CF_HELIX = {'A':1.42,'R':0.98,'N':0.67,'D':1.01,'C':0.70,'Q':1.11,'E':1.51,
            'G':0.57,'H':1.00,'I':1.08,'L':1.21,'K':1.16,'M':1.45,'F':1.13,
            'P':0.57,'S':0.77,'T':0.83,'W':1.08,'Y':0.69,'V':1.06}
# Chou-Fasman beta-sheet propensity (aggregation proxy)
CF_BETA = {'A':0.83,'R':0.93,'N':0.89,'D':0.54,'C':1.19,'Q':1.10,'E':0.37,
           'G':0.75,'H':0.87,'I':1.60,'L':1.30,'K':0.74,'M':1.05,'F':1.38,
           'P':0.55,'S':0.75,'T':1.19,'W':1.37,'Y':1.47,'V':1.70}
# Boman-like protein-binding index residue values (Radzicka/Boman, approx; Pro~0)
BOMAN = {'L':-4.92,'I':-4.92,'V':-4.04,'F':-2.98,'M':-2.35,'W':-2.33,'A':-1.81,
         'C':-1.28,'G':-0.94,'Y':0.14,'T':2.57,'S':3.40,'H':4.66,'Q':5.54,
         'K':5.55,'N':6.64,'E':6.81,'D':8.72,'R':14.92,'P':0.0}
# EMBOSS-style pKa for charge / pI
PKA_POS = {'Nterm':8.6,'K':10.8,'R':12.5,'H':6.5}
PKA_NEG = {'Cterm':3.6,'D':3.9,'E':4.1,'C':8.5,'Y':10.1}

HYDROPHOBIC = set("ACFILMVWY")
AROMATIC = set("FWY")
BETA_BRANCHED = set("IVT")
AGG_PRONE = set("IVFYWLT")
CATIONIC = set("KR")

# --- Descriptors -------------------------------------------------------------
def net_charge(seq, pH=7.0):
    pos = 1.0/(1.0+10**(pH-PKA_POS['Nterm']))
    for a in seq:
        if a in ('K','R','H'):
            pos += 1.0/(1.0+10**(pH-PKA_POS[a]))
    neg = 1.0/(1.0+10**(PKA_NEG['Cterm']-pH))
    for a in seq:
        if a in ('D','E','C','Y'):
            neg += 1.0/(1.0+10**(PKA_NEG[a]-pH))
    return pos - neg

def isoelectric_point(seq):
    lo, hi = 0.0, 14.0
    for _ in range(40):
        mid = (lo+hi)/2
        if net_charge(seq, mid) > 0: lo = mid
        else: hi = mid
    return (lo+hi)/2

def mean_hydrophobicity(seq):   # Eisenberg mean (can be negative)
    return sum(EISENBERG[a] for a in seq)/len(seq)

def gravy(seq):
    return sum(KD[a] for a in seq)/len(seq)

def hydrophobic_moment(seq, angle_deg=100.0):
    ang = math.radians(angle_deg)
    sx = sum(EISENBERG[a]*math.cos(i*ang) for i,a in enumerate(seq))
    sy = sum(EISENBERG[a]*math.sin(i*ang) for i,a in enumerate(seq))
    return math.sqrt(sx*sx+sy*sy)/len(seq)

def hydrophobic_fraction(seq):
    return sum(1 for a in seq if a in HYDROPHOBIC)/len(seq)

def aromatic_fraction(seq):
    return sum(1 for a in seq if a in AROMATIC)/len(seq)

def cationic_fraction(seq):
    return sum(1 for a in seq if a in CATIONIC)/len(seq)

def boman_index(seq):
    return sum(BOMAN[a] for a in seq)/len(seq)

def helix_propensity(seq):
    return sum(CF_HELIX[a] for a in seq)/len(seq)

def max_run_same(seq):
    best=cur=1
    for i in range(1,len(seq)):
        cur = cur+1 if seq[i]==seq[i-1] else 1
        best=max(best,cur)
    return best

def max_hydrophobic_run(seq):
    best=cur=0
    for a in seq:
        cur = cur+1 if a in HYDROPHOBIC else 0
        best=max(best,cur)
    return best

def max_agg_run(seq):
    best=cur=0
    for a in seq:
        cur = cur+1 if a in AGG_PRONE else 0
        best=max(best,cur)
    return best

# --- Penalty / reward sub-scores (each mapped to [0,1]) ----------------------
def _band(x, lo, hi, soft=1.0):
    """1.0 inside [lo,hi], linearly decaying outside over 'soft' width."""
    if lo <= x <= hi: return 1.0
    d = (lo-x) if x<lo else (x-hi)
    return max(0.0, 1.0 - d/soft)

def hemolysis_penalty(seq):
    hf = hydrophobic_fraction(seq); af = aromatic_fraction(seq)
    he = mean_hydrophobicity(seq); run = max_hydrophobic_run(seq)
    w = Counter(seq)['W']
    p = 0.0
    p += max(0.0, hf-0.50)*2.0
    p += max(0.0, af-0.15)*1.8
    p += max(0.0, he-0.05)*0.6
    p += max(0, run-4)*0.10
    p += max(0, w-2)*0.12
    return min(1.0, p)

def aggregation_penalty(seq):
    beta = sum(CF_BETA[a] for a in seq)/len(seq)
    run = max_agg_run(seq)
    p = 0.0
    p += max(0.0, beta-1.05)*0.8
    p += max(0, run-3)*0.12
    return min(1.0, p)

def synth_penalty(seq):
    c = Counter(seq); n=len(seq); p=0.0
    cys = c['C']
    if cys % 2 == 1: p += 0.30                    # unpaired thiol
    if cys > 2: p += 0.10*(cys-2)
    if max_run_same(seq) >= 4: p += 0.20          # homorepeat coupling issues
    p += min(0.15, 0.05*c['M'])                   # Met oxidation
    if seq[0] in ('Q','N','C'): p += 0.10         # pyroGlu / N-term side rxns
    bb = sum(1 for a in seq if a in BETA_BRANCHED)/n
    if bb > 0.35: p += 0.15                        # on-resin aggregation
    if n > 40: p += 0.10*(n-40)/10.0
    return min(1.0, p)

def charge_extreme_penalty(nc):
    if nc <= 0: return 1.0
    if nc > 9:  return min(1.0, (nc-9)*0.25)       # polycation nephrotox/nonspecific
    return 0.0

# --- Class-aware reward ------------------------------------------------------
def reward(seq, cls, nc, uH, hf, hp):
    L = len(seq)
    s_charge = _band(nc, 3.0, 8.0, soft=4.0)
    s_len    = _band(L, 12, 30, soft=10.0)
    if cls in ("proline_rich", "random_cationic_coil"):
        # intracellular / disordered mechanisms: do not demand high uH or hydrophobic face
        s_moment = 0.6
        s_hydro  = _band(hf, 0.15, 0.40, soft=0.25)
        s_class  = _band(nc, 4.0, 10.0, soft=4.0)   # they lean on charge
    elif cls == "beta_hairpin":
        s_moment = min(1.0, uH/0.45)
        s_hydro  = _band(hf, 0.30, 0.52, soft=0.20)
        beta = sum(CF_BETA[a] for a in seq)/L
        s_class  = _band(beta, 0.95, 1.25, soft=0.4)
    else:  # helical_amphipathic, cyclic_mimic, trp_arg_rich
        s_moment = min(1.0, uH/0.55)
        s_hydro  = _band(hf, 0.32, 0.52, soft=0.20)
        s_class  = min(1.0, hp/1.15)
    s_anchor = min(1.0, (Counter(seq)['W']*0.15 + cationic_fraction(seq)*0.6))
    R = (0.28*s_charge + 0.24*s_moment + 0.18*s_hydro +
         0.12*s_len + 0.12*s_class + 0.06*s_anchor)
    return R

def design_priority_score(seq, cls):
    nc = net_charge(seq)
    uH = hydrophobic_moment(seq)
    hf = hydrophobic_fraction(seq)
    hp = helix_propensity(seq)
    R = reward(seq, cls, nc, uH, hf, hp)
    P = (0.45*hemolysis_penalty(seq) + 0.20*aggregation_penalty(seq) +
         0.20*synth_penalty(seq) + 0.15*charge_extreme_penalty(nc))
    dps = R*(1.0 - 0.75*P)
    return max(0.0, min(1.0, dps)), dict(charge=nc, uH=uH, hf=hf, hp=hp,
               hemo=hemolysis_penalty(seq), agg=aggregation_penalty(seq),
               synth=synth_penalty(seq))

# --- Generators --------------------------------------------------------------
def _pick(weights):
    letters, w = zip(*weights.items())
    return random.choices(letters, weights=w, k=1)[0]

CAT_POLAR = {'K':5,'R':4,'H':1,'N':1,'Q':1,'S':1,'T':1,'G':1,'D':0.3,'E':0.3}
HYDRO_FACE = {'L':5,'I':3,'F':2,'V':3,'A':3,'W':1,'M':1,'Y':1}

def gen_helical(Lrange=(14,28)):
    L = random.randint(*Lrange)
    seq=[]
    # helical wheel; nonpolar face = angles within +-100 deg of 200 deg reference
    for i in range(L):
        ang = (i*100) % 360
        on_nonpolar = (ang <= 100) or (ang >= 260)
        seq.append(_pick(HYDRO_FACE) if on_nonpolar else _pick(CAT_POLAR))
    return "".join(seq)

def gen_beta_hairpin(Lrange=(14,26)):
    L = random.randint(*Lrange)
    half = (L-2)//2
    turn = random.choice(["NG","PG","DG","NPG","PDG"])
    strand_res = {'K':4,'R':4,'W':1.5,'I':2,'V':2,'F':1.5,'Y':1.5,'L':2,'T':1.5}
    s1 = "".join(_pick(strand_res) for _ in range(half))
    s2 = "".join(_pick(strand_res) for _ in range(half))
    seq = list(s1+turn+s2)
    # optionally add a disulfide pair (Cys near each strand start)
    if random.random() < 0.6 and len(seq) >= 8:
        i,j = 1, len(seq)-2
        seq[i]='C'; seq[j]='C'
    return "".join(seq)

def gen_proline_rich(Lrange=(12,24)):
    L = random.randint(*Lrange)
    motifs = ["PR","RP","PRP","RPR","PPR","RPP","PW","WR","PK","KP"]
    seq=""
    while len(seq) < L:
        seq += random.choice(motifs)
    seq = seq[:L]
    # ensure cationic and not too hydrophobic
    return seq

def gen_cyclic_mimic(Lrange=(10,18)):
    L = random.randint(*Lrange)
    # Gramicidin-S inspired alternating cationic/hydrophobic, Cys-flanked for cyclization
    alt_cat = {'K':4,'R':4,'H':1}
    alt_hyd = {'L':3,'V':3,'F':2,'I':2,'W':1,'Y':1}
    core=[]
    for i in range(L-2):
        core.append(_pick(alt_cat) if i%2==0 else _pick(alt_hyd))
    seq = "C"+"".join(core)+"C"   # disulfide-cyclizable
    return seq

def gen_trp_arg_rich(Lrange=(8,16)):
    L = random.randint(*Lrange)
    w = {'R':5,'W':3,'K':3,'P':1,'F':1,'L':1,'I':1,'V':1}
    seq="".join(_pick(w) for _ in range(L))
    return seq

def gen_random_cationic_coil(Lrange=(12,26)):
    L = random.randint(*Lrange)
    w = {'K':4,'R':3,'G':2,'S':2,'A':2,'P':1.5,'Q':1,'N':1,'L':1.5,'I':1,'V':1,'T':1}
    seq="".join(_pick(w) for _ in range(L))
    return seq

GENERATORS = [
    (gen_helical,               0.36, "helical_amphipathic"),
    (gen_beta_hairpin,          0.15, "beta_hairpin"),
    (gen_proline_rich,          0.12, "proline_rich"),
    (gen_cyclic_mimic,          0.11, "cyclic_mimic"),
    (gen_trp_arg_rich,          0.12, "trp_arg_rich"),
    (gen_random_cationic_coil,  0.14, "random_cationic_coil"),
]

# --- Canonical AMP novelty gate (coarse placeholder for MMseqs2/MarLys) -------
CANONICAL = [
 "LLGDFFRKSKEKIGKEFKRIVQRIKDFLRNLVPRTES",   # LL-37
 "GIGKFLHSAKKFGKAFVGEIMNS",                  # magainin 2
 "GIGAVLKVLTTGLPALISWIKRKRQQ",               # melittin
 "ILPWKWPWWPWRR",                            # indolicidin
 "RGGRLCYCRRRFCVCVGR",                       # protegrin-1
 "KWKLFKKIEKVGQNIRDGIIKAGPAVAVVGQATQIAK",    # cecropin A
 "TRSSRAGLQFPVGRVHRLLRK",                    # buforin II
 "GLFDIIKKIAESF",                            # aurein 1.2
 "FLPLIGRVLSGIL",                            # temporin A
 "GIGKFLKKAKKFGKAFVKILKK",                   # pexiganan / MSI-78
 "GWGSFFKKAAHVGKHVGKAALTHYL",                # pleurocidin
 "RIIDLLWRVRRPQKPKFVTVWVR",                  # PMAP-23
 "ALWKTMLKKLGTMALHAGKAALGAAADTISQGTQ",       # dermaseptin
 "FFHHIFRGIVHVGKTIHRLVTG",                   # piscidin 1
 "RLCRIVVIRVCR",                             # bactenecin
 "DSHAKRHHGYKRKFHEKHHSHRGY",                 # histatin 5
 "KWCFRVCYRGICYRRCR",                        # tachyplesin I
 "FKCRRWQWRMKKLGAPSITCVRRAF",                # lactoferricin B
 "KFFRKLKKSVKKRAKEFFKKPRVIGVSIPF",           # cathelicidin-BF (approx)
 "INLKALAALAKKIL",                           # mastoparan
 "RGLRRLGRKIAHGVKKYGPTVLRIIRIAG",            # SMAP-29
 "VFQFLGKIIHHVGNFVHGFSHVF",                  # clavanin A
 "GLLDFLKKAAEKLLKKAAEK",                     # generic amphipathic decoy
 "KRWWKWWRR",                                # short WR decoy
 "GKPRPYSPRPTSHPRPIRV",                      # oncocin-like PrAMP
 "GNNRPVYIPQPRPPHPRL",                       # apidaecin-like PrAMP
 "RRWCFRVCYKGFCYRKCR",                       # theta-defensin-like
 "ACYCRIPACIAGERRYGTCIYQGRLWAFCC",           # HNP-1-like defensin
 "GWLRDVWDWLR",                              # tryptophan-zipper decoy
 "KLAKLAKKLAKLAK",                           # (KLAKLAK)2 amphipathic
]
def kmers(s,k=3): return {s[i:i+k] for i in range(len(s)-k+1)} if len(s)>=k else {s}
CANON_K = [kmers(c,3) for c in CANONICAL]

def max_identity_to_canonical(seq):
    ks = kmers(seq,3)
    if not ks: return 1.0
    best=0.0
    for ck in CANON_K:
        inter=len(ks & ck)
        cont = inter/min(len(ks),len(ck))   # k-mer containment
        best=max(best,cont)
    return best

# --- Build library -----------------------------------------------------------
TARGET = 50000
rows=[]; seen=set()
attempts=0; dropped_novelty=0; dropped_dup=0; dropped_len=0
while len(rows) < TARGET and attempts < TARGET*8:
    attempts+=1
    r = random.random(); acc=0.0
    for gfn, w, cls in GENERATORS:
        acc+=w
        if r<=acc: break
    seq = gfn()
    if not (8 <= len(seq) <= 50) or any(a not in AA for a in seq):
        dropped_len+=1; continue
    if seq in seen:
        dropped_dup+=1; continue
    if max_identity_to_canonical(seq) > 0.72:
        dropped_novelty+=1; continue
    seen.add(seq)
    dps, feats = design_priority_score(seq, cls)
    rows.append((seq, cls, dps, feats))

df = pd.DataFrame([{
    "peptide_sequence": s,
    "class": c,
    "length": len(s),
    "net_charge": round(f["charge"],2),
    "uH_eisenberg": round(f["uH"],3),
    "hydrophobic_frac": round(f["hf"],3),
    "helix_propensity": round(f["hp"],3),
    "isoelectric_point": round(isoelectric_point(s),2),
    "boman_index": round(boman_index(s),2),
    "gravy": round(gravy(s),3),
    "hemolysis_pen": round(f["hemo"],3),
    "aggregation_pen": round(f["agg"],3),
    "synth_pen": round(f["synth"],3),
    "canonical_maxid": round(max_identity_to_canonical(s),3),
    "DPS": round(d,4),
} for (s,c,d,f) in [(s,c,d,f) for (s,c,d,f) in rows]])

# notes column (compact)
def flags(row):
    fl=[]
    if row.hemolysis_pen>0.35: fl.append("hemo")
    if row.aggregation_pen>0.35: fl.append("agg")
    if row.synth_pen>0.3: fl.append("synth")
    if row.net_charge>9: fl.append("hypercationic")
    return ",".join(fl) if fl else "-"
df["notes"] = df.apply(lambda r: (
    f"class={r['class']}; DPS={r['DPS']}; charge={r['net_charge']:+}; "
    f"uH={r['uH_eisenberg']}; Hfrac={r['hydrophobic_frac']}; len={r['length']}; "
    f"pI={r['isoelectric_point']}; flags={flags(r)}"), axis=1)

# --- Deliverable (d): peptides_50k.tsv  [peptide_sequence, notes] -------------
df_out = df[["peptide_sequence","notes"]]
df_out.to_csv("/home/claude/peptides_50k.tsv", sep="\t", index=False)

# full table for downstream / auditing
df.to_csv("/home/claude/peptides_50k_full.tsv", sep="\t", index=False)

# per-class DPS summary (for documentation / audit)
per_class_dps = df.groupby("class")["DPS"].describe()[["mean","50%","max","count"]]
per_class_dps.to_csv("/home/claude/per_class_dps.csv")

# --- Top-100: mechanism-diversified selection --------------------------------
# Rationale: BATTLE-AMP shows the best candidate is pathogen-dependent and that
# activity cliffs are unresolved; betting the top list on one structural class is
# fragile. So we hedge: guarantee every mechanism appears (floor) and cap any
# single class, while ranking by DPS and enforcing k-mer diversity throughout.
CLASSES = [c for _,_,c in GENERATORS]
PER_CLASS_CAP = 24
DIV_THRESH = 0.6
df_sorted = df.sort_values("DPS", ascending=False).reset_index(drop=True)

def kmer_ok(ks, sel_k):
    return all((len(ks & sk)/min(len(ks),len(sk))) < DIV_THRESH for sk in sel_k)

TOP_NOVELTY_MAXID = 0.5   # flagship candidates held to a stricter novelty bar
selected=[]; sel_k=[]; cls_count=Counter()
# Pass 1 (floor): best diversity-passing, novelty-passing peptide from each class
for c in CLASSES:
    for _,row in df_sorted[df_sorted["class"]==c].iterrows():
        if row.canonical_maxid >= TOP_NOVELTY_MAXID: continue
        ks = kmers(row.peptide_sequence,3)
        if kmer_ok(ks, sel_k):
            selected.append(row); sel_k.append(ks); cls_count[c]+=1; break
# Pass 2 (fill): DPS order, respecting per-class cap + diversity + novelty
sel_seqs = {r.peptide_sequence for r in selected}
for _,row in df_sorted.iterrows():
    if len(selected) >= 100: break
    if row.peptide_sequence in sel_seqs: continue
    if cls_count[row["class"]] >= PER_CLASS_CAP: continue
    if row.canonical_maxid >= TOP_NOVELTY_MAXID: continue
    ks = kmers(row.peptide_sequence,3)
    if kmer_ok(ks, sel_k):
        selected.append(row); sel_k.append(ks); cls_count[row["class"]]+=1
        sel_seqs.add(row.peptide_sequence)

top = pd.DataFrame(selected).sort_values("DPS", ascending=False).reset_index(drop=True)
top.index = top.index+1
top.to_csv("/home/claude/top_100_full.tsv", sep="\t")

# --- Summary stats -----------------------------------------------------------
stats = {
    "library_size": len(df),
    "attempts": attempts,
    "dropped_novelty_gate": dropped_novelty,
    "dropped_exact_dup": dropped_dup,
    "dropped_len_or_invalid": dropped_len,
    "class_mix": df["class"].value_counts().to_dict(),
    "len_min": int(df.length.min()), "len_max": int(df.length.max()),
    "len_mean": round(df.length.mean(),1),
    "charge_mean": round(df.net_charge.mean(),2),
    "charge_median": round(df.net_charge.median(),2),
    "uH_mean": round(df.uH_eisenberg.mean(),3),
    "hydrophobic_frac_mean": round(df.hydrophobic_frac.mean(),3),
    "pI_mean": round(df.isoelectric_point.mean(),2),
    "canonical_maxid_mean": round(df.canonical_maxid.mean(),3),
    "canonical_maxid_p95": round(df.canonical_maxid.quantile(0.95),3),
    "DPS_mean": round(df.DPS.mean(),4),
    "DPS_p90": round(df.DPS.quantile(0.90),4),
    "DPS_max": round(df.DPS.max(),4),
    "top100_class_mix": top["class"].value_counts().to_dict(),
    "top100_DPS_min": round(top.DPS.min(),4),
    "top100_DPS_max": round(top.DPS.max(),4),
    "top100_charge_mean": round(top.net_charge.mean(),2),
    "top100_hemo_mean": round(top.hemolysis_pen.mean(),3),
    "top100_canonical_maxid_max": round(top.canonical_maxid.max(),3),
}
with open("/home/claude/stats.json","w") as fh:
    json.dump(stats, fh, indent=2)
print(json.dumps(stats, indent=2))
